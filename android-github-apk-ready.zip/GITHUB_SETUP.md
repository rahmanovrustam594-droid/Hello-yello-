# GitHub da APK Build Qilish

Bu loyiha GitHub Actions bilan automatic APK build qilish uchun tayyorlangan.

## ✅ Setup Instructions

### 1. Repository yaratish
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/yourusername/yourrepo.git
git push -u origin main
```

### 2. GitHub Actions Workflow
`.github/workflows/build-apk.yml` fayli avtomatik ravishda:
- ✅ Main/master/develop shoxiga push bo'lganda
- ✅ Pull request ochilganda
- ✅ Release tag yaratilganda

APK build qiladi.

### 3. Build Natijalar

**Artifacts (Har qanday push'da):**
- 📦 `release-apk` - Release APK
- 📦 `debug-apk` - Debug APK

**Release**'ga upload:**
```bash
git tag v1.0.0
git push origin v1.0.0
```

## 🔐 Kerakli Setup (Ixtiyoriy - Signing uchun)

Release APK imzolash uchun:

### 1. Keystore yaratish (lokal)
```bash
keytool -genkey -v -keystore my-release-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias my-key-alias
```

### 2. GitHub Secrets qo'shish
Settings → Secrets → New repository secret:
- `KEYSTORE_FILE` - Base64'ga o'girilgan .jks fayli
- `KEYSTORE_PASSWORD` - Keystore paroli
- `KEY_ALIAS` - Key alias
- `KEY_PASSWORD` - Key paroli

Base64 encoding:
```bash
base64 -i my-release-key.jks | pbcopy
```

### 3. Workflow faylni update qilish
`build-apk.yml`'ga signing qo'shish:

```yaml
- name: Build Signed Release APK
  env:
    KEYSTORE_BASE64: ${{ secrets.KEYSTORE_FILE }}
    KEYSTORE_PASSWORD: ${{ secrets.KEYSTORE_PASSWORD }}
    KEY_ALIAS: ${{ secrets.KEY_ALIAS }}
    KEY_PASSWORD: ${{ secrets.KEY_PASSWORD }}
  run: |
    echo $KEYSTORE_BASE64 | base64 -d > $GITHUB_WORKSPACE/keystore.jks
    ./gradlew assembleRelease \
      -Pandroid.injected.signing.store.file=$GITHUB_WORKSPACE/keystore.jks \
      -Pandroid.injected.signing.store.password=$KEYSTORE_PASSWORD \
      -Pandroid.injected.signing.key.alias=$KEY_ALIAS \
      -Pandroid.injected.signing.key.password=$KEY_PASSWORD
```

## 🚀 APK Download qilish

1. **GitHub Actions tab'dan:** Actions → Latest workflow → Artifacts
2. **Release'dan:** Releases → Download APK

## 📱 APK Instullash

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## 🐛 Troubleshooting

### Gradle error
```bash
./gradlew clean
./gradlew wrapper --gradle-version=8.0
```

### JDK version issue
Workflow'da Java version'ni o'zgartirib ko'ring (17, 21, etc)

### Build xotirasi
`gradle.properties` ga qo'shish:
```
org.gradle.jvmargs=-Xmx2048m
```

## 📚 Resources
- [Android Build Guide](https://developer.android.com/studio/build)
- [GitHub Actions](https://github.com/features/actions)
- [Gradle Docs](https://gradle.org/docs/)
